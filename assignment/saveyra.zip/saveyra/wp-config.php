<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'shrivats_saveyra' );

/** MySQL database username */
define( 'DB_USER', 'shrivats_saveyra' );

/** MySQL database password */
define( 'DB_PASSWORD', 'saveyra@2020' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'R)ct0og+b650N)K2KUM?F6CW)&vz[qh&_~8t?m)}EB{dbwepc36kEYiIqn#^.L1t' );
define( 'SECURE_AUTH_KEY',  '7XC;C%3Pp7A v0L&wCVg,zZmsPkKB?}7u9S*aph5k1rVL={N;xfBM[x3yUm ~wO[' );
define( 'LOGGED_IN_KEY',    '~,L/C#/NXh*}p8$qmT^;T)P$#)XCJ>`+Ud9cpnc~4sml47[H0F1yOiYGP)Nzb3BP' );
define( 'NONCE_KEY',        'itFma4<kAMD@$~[v>ezPBk3)[n:?DV7:,whApg>v!lR0>r$s<WcFj?FgO0,)U@pE' );
define( 'AUTH_SALT',        '6=71kADqTBc@+OW*E2n!8|NTw3*1f8NcPP8X~[,TOc=V*tU,5HZr vA90y8Mo&3s' );
define( 'SECURE_AUTH_SALT', 'Ma1cj$ooftTcnup7r[mM4@/sORP^YA@oLNuBVU$iR2MG>O17;_U<K=@a~R6ax@b}' );
define( 'LOGGED_IN_SALT',   ')+q:#Px:8%oR=LTSXI}fl;j4xLyYo7UiLec3tz-o_ZO4Ic6b&}xmH;rcVjByap<P' );
define( 'NONCE_SALT',       'KI0Vi6<6SMCb> *|rF2U8ZES}w!h~@l2RveX,d](Z#VNzl4pR!u1Y70=T]ln|`#+' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'saveyra_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
